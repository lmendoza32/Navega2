package com.example.navega2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val webBrowser = findViewById<WebView>(R.id.webWeb) as WebView
        webBrowser.webViewClient = object: WebViewClient(){
            override fun shouldOverrideUrlLoading(
                view: WebView?,
                url: String):
                    Boolean {
                if(url != null){
                    view?.loadUrl(url)
                }
                return true
            }
        }
        webBrowser.loadUrl("https://www.google.com")
        webBrowser.settings.javaScriptEnabled = true
        webBrowser.settings.allowContentAccess = true
        webBrowser.settings.domStorageEnabled = true
        webBrowser.settings.useWideViewPort = true
    }
}